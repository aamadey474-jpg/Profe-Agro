# Profesorado en Agronomía | Diálogo con un egresado

Humano digital (agente de voz de ElevenLabs + busto 3D con Three.js) que cuenta cómo es el Profesorado de Educación Secundaria en Agronomía de la EFA Fortaleza Campesina 141, de primero a cuarto año.

## Publicar con GitHub Pages
1. Creá un repositorio nuevo y subí `index.html` y `.nojekyll`.
2. Settings → Pages → Branch: `main`, carpeta `/ (root)`.
3. Abrí `https://TU_USUARIO.github.io/NOMBRE_DEL_REPO/`.

## Agente de ElevenLabs
- Autenticación desactivada (agente público). Si activás dominios permitidos, agregá `TU_USUARIO.github.io`.
- Para usar otro agente: `index.html?agente=TU_ID`.
